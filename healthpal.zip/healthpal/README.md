# HealthPal

An all-in-one virtual health platform with three tools:

- Medical AI: a chatbot that gives general health guidance based on symptoms you describe.
- Therapist AI: an empathetic chatbot you can talk to with your voice; it speaks its replies back to you.
- Find Clinics: uses your phone's location to show nearby clinics, hospitals, doctors, and pharmacies sorted by distance.

Built with Next.js (App Router). No paid services required - the AI is powered by the free Groq API, voice uses the browser's built-in Web Speech API, and clinic search uses the free OpenStreetMap Overpass API. Nothing to install on your phone; it's a website.

---

## 1. Get a free Groq API key (2 minutes)

1. Go to https://console.groq.com
2. Sign up (free, no credit card).
3. Go to API Keys, then Create API Key.
4. Copy the key. You will paste it into Vercel in step 3.

---

## 2. Put this code on GitHub

1. Create a new repository on https://github.com (e.g. healthpal).
2. Upload all the files in this folder to that repository (drag-and-drop works fine on GitHub's web UI, or use git push if you're comfortable with git).

Make sure the folder structure stays the same: app/, components/, package.json, etc. should all be at the top level of the repo.

---

## 3. Deploy to Vercel (free)

1. Go to https://vercel.com and sign up / log in (you can use your GitHub account).
2. Click "Add New..." then "Project".
3. Select the GitHub repository you just created and click Import.
4. Vercel will auto-detect it as a Next.js project. Leave the build settings as default.
5. Before deploying, open Environment Variables and add:
   - Name: GROQ_API_KEY
   - Value: (paste the key you copied in step 1)
6. Click Deploy.

After a minute or two, Vercel gives you a live URL like https://healthpal-yourname.vercel.app - that's your app, live on the internet.

---

## 4. Using the app

- Home (/) - overview with links to all three tools.
- Medical AI (/medical) - type your symptoms, get conversational guidance.
- Therapist AI (/therapist) - type or tap the mic to talk; works best in Chrome (desktop or Android) for voice input. Replies are read aloud automatically (toggle this off if you prefer).
- Find Clinics (/clinics) - tap "Use my location", allow location access when your browser asks, and see nearby clinics sorted by distance. Tap any result to open it in OpenStreetMap.

---

## 5. Running locally (optional)

If you want to test on your computer before deploying:

```bash
npm install
```

Create a file named .env.local in the project root with:

```
GROQ_API_KEY=your_groq_api_key_here
```

Then run:

```bash
npm run dev
```

Open http://localhost:3000 in your browser.

---

## Notes and customization

- Models: the API route (app/api/chat/route.js) uses Groq's llama-3.3-70b-versatile model. You can swap this for any other Groq model name if you want.
- System prompts: the personality and behavior of the Medical AI and Therapist AI are defined in app/api/chat/route.js under SYSTEM_PROMPTS. Edit these to change tone or focus.
- Design: colors, fonts, and layout live in app/globals.css.
- Disclaimer: this app is for informational and supportive purposes only and is not a substitute for professional medical or mental health care. Keep the in-app disclaimers visible.
