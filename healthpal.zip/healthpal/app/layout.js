import "./globals.css";
import Nav from "../components/Nav";

export const metadata = {
  title: "HealthPal — Your AI health companion",
  description:
    "Get instant AI medical guidance, talk to an empathetic AI therapist, and find nearby clinics — all in one place.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Plus+Jakarta+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <Nav />
        {children}
        <footer className="site-footer">
          <div className="shell">
            <span>HealthPal — built for one weekend, made to keep helping.</span>
            <span>Not a substitute for professional medical care.</span>
          </div>
        </footer>
      </body>
    </html>
  );
}
